#-*- coding: utf-8 -*-
import sys
import requests


data ={ 'car_String':'망g',
        'car_number':5412,
        'car_where':'ags',
        'car_picture_url':'sdgs' }

path ="http://ec2-52-79-216-228.ap-northeast-2.compute.amazonaws.com/rasp_server.php"

resq = requests.post(path, data=data)


